#! /bin/bash


export RECREL=CMSSW_10_2_18
export SCRAM_ARCH=slc7_amd64_gcc700


#export FILE1=file:root://cmseos.fnal.gov//eos/uscms/store/user/ckar/PYTHIA8_BsToMuMuPhi_2018_Gen/crab_crabjob_Genfile_2018nofilterMC_private/191223_064706/0000/PYTHIA8-BsToMuMuPhi-RunIIFall18GS-00134_nofilter_step0_$1.root
#export FILE1=/store/mc/RunIISummer16MiniAODv3/BsToJpsiPhi_BMuonFilter_SoftQCDnonD_TuneCUEP8M1_13TeV-pythia8-evtgen/MINIAODSIM/PUMoriond17_94X_mcRun2_asymptotic_v3_ext1-v2/60000/167E760C-0EEA-E911-80D6-0CC47AE2BAAE.root


export FILE1=$2
export FILE2="BCToDSMuMu-2018B_MINIAOD_$1.root"


echo "========================"
echo "====> SGE  wrapper <===="
echo "========================"

echo "--> Running SGE digi-reco job wrapper"

echo $FILE1
echo $FILE2



# ----------------------------------------------------------------------
# -- The Basics
# ----------------------------------------------------------------------
echo "--> Environment"
date
hostname
uname -a
df -kl
limit coredumpsize 0

source /cvmfs/cms.cern.ch/cmsset_default.sh
echo "-> which edg-gridftp-ls"
which edg-gridftp-ls
echo "-> which globus-url-copy"
which globus-url-copy
echo "-> which srmcp"
which srmcp

pwd
echo "--> End of env testing"

# BATCH START

# ----------------------------------------------------------------------
# -- Setup CMSSW
# ----------------------------------------------------------------------
echo "--> Setup CMSSW"
pwd
date
eval `scramv1 project CMSSW CMSSW_10_2_18`
#cmsrel CMSSW_10_2_18
#
cd CMSSW_10_2_18/src/
tar -zxvf ../../bctodsmumu_analysis.tar.gz


ls -ltr
eval `scramv1 runtime -sh`
pwd

scramv1 b ProjectRename
#scramv1 b clean
#scramv1 b myanalyzer
#cmsenv

scramv1 b

cd bctodsmumu_analysis/BcToDsMuMuPAT/test/
cp ../../../../../BcToDsMuMuRootupler_mod.py

cmsRun BcToDsMuMuRootupler_mod.py

ls -rtl

xrdcp -f BCToDSMuMu-2018B_MINIAOD_$1.root root://cmseos.fnal.gov//eos/uscms/store/user/ckar/BsToJpsiPhi_Condor/BCToDSMuMu-2018B_MINIAOD_$1.root


# BATCH END

echo "run: This is the end, my friend"
cd ${_CONDOR_SCRATCH_DIR}
rm -rf CMSSW_10_2_18
